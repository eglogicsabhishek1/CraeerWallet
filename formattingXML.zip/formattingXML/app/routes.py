import re
import tempfile
import xml.sax
import logging
import os
from fastapi import APIRouter, UploadFile, File, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import Job
from app.parsers.canada_parser import CanadaHandler
from app.parsers.cws_us_parser import CWSHandler

router = APIRouter()

logging.basicConfig(level=logging.INFO)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def clean_xml(xml_str: str) -> str:
    # Remove BOM (Byte Order Mark) if present
    xml_str = xml_str.lstrip('\ufeff')

    # Fix unescaped ampersands
    xml_str = re.sub(r'&(?!amp;|lt;|gt;|quot;|apos;)', '&amp;', xml_str)

    # Escape ampersands in CDATA sections
    xml_str = re.sub(r'<!\[CDATA\[(.*?)\]\]>', lambda m: '<![CDATA[' + re.sub(r'&', '&amp;', m.group(1)) + ']]>', xml_str)

    # Remove illegal control characters
    xml_str = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F]', '', xml_str)

    # Replace other invalid characters
    xml_str = re.sub(r'[^\x09\x0A\x0D\x20-\uD7FF\uE000-\uFFFD]', '', xml_str)

    # Normalize whitespace in tags
    xml_str = re.sub(r'>\s+<', '><', xml_str)

    # Normalize newlines in CDATA
    xml_str = re.sub(r'<!\[CDATA\[(.*?)\]\]>', lambda m: '<![CDATA[' + re.sub(r'\r\n|\r|\n', '', m.group(1)) + ']]>', xml_str)

    return xml_str


@router.post("/upload/")
async def upload(file: UploadFile = File(...), source: str = "canada", db: Session = Depends(get_db)):
    contents = await file.read()

    # Decode and clean XML
    cleaned = clean_xml(contents.decode("utf-8").strip())

    # Conditionally wrap in <root> if multiple top-level <job> tags
    if cleaned.startswith("<job>"):
        wrapped = f"<root>{cleaned}</root>"
    else:
        wrapped = cleaned

    logging.info(f"Cleaned XML preview:\n{wrapped[:500]}...")

    # Write to temp file
    with tempfile.NamedTemporaryFile(delete=False, mode='w', encoding='utf-8') as temp:
        temp.write(wrapped)
        temp.flush()
        temp_path = temp.name

    # Choose handler
    if source.lower() == "canada":
        handler = CanadaHandler()
    elif source.lower() == "us":
        handler = CWSHandler()
    else:
        os.remove(temp_path)
        return {"error": "Unknown source format"}

    try:
        # Parse using SAX
        xml.sax.parse(temp_path, handler)
    except xml.sax.SAXParseException as e:
        logging.error(f"SAX Parsing Error at line {e.getLineNumber()} col {e.getColumnNumber()}: {e}")
        os.remove(temp_path)
        return {"error": f"XML Parsing failed: {e}"}

    # Save parsed jobs
    for job_data in handler.jobs:
        job_data["source"] = source
        job = Job(**job_data)
        db.add(job)

    db.commit()
    os.remove(temp_path)

    return {"message": f"{len(handler.jobs)} jobs added from {source}!"}
