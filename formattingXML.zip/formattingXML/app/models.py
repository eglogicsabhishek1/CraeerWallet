from sqlalchemy import Column, Integer, String, DateTime, Float
from app.database import Base
from datetime import datetime, UTC

class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    company = Column(String)
    description = Column(String)
    location = Column(String)
    url = Column(String)
    reference = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
    cpc = Column(Float, nullable=True)
    source = Column(String(100))
