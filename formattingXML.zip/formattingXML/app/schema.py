from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class JobCreate(BaseModel):
    title: str
    company: str
    description: Optional[str]
    location: Optional[str]
    url: str
    reference: Optional[str]
    created_at: Optional[datetime]
    cpc: Optional[float]
