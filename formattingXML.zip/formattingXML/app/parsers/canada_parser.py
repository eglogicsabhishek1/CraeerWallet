import xml.sax
from datetime import datetime

class CanadaHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.jobs = []
        self.current_data = ""
        self.buffer = ""
        self.current_job = None

    def startElement(self, tag, attrs):
        self.current_data = tag
        self.buffer = ""
        if tag == "job":
            self.current_job = {}

    def endElement(self, tag):
        if self.current_job is not None:
            content = self.buffer.strip()

            if self.current_data == "title":
                self.current_job["title"] = content
            elif self.current_data == "company":
                self.current_job["company"] = content
            elif self.current_data == "description":
                self.current_job["description"] = content
            elif self.current_data == "url":
                self.current_job["url"] = content
            elif self.current_data == "city":
                self.current_job["location"] = content
            elif self.current_data == "createdat":
                try:
                    self.current_job["created_at"] = datetime.strptime(content, "%a, %d %b %Y %H:%M:%S %z")
                except:
                    self.current_job["created_at"] = None
            elif self.current_data == "referencenumber":
                self.current_job["reference"] = content
            elif self.current_data == "campaign_tcpa":
                try:
                    self.current_job["cpc"] = float(content)
                except ValueError:
                    self.current_job["cpc"] = None

            if tag == "job":
                self.jobs.append(self.current_job)
                self.current_job = None

        self.current_data = ""
        self.buffer = ""

    def characters(self, content):
        self.buffer += content
