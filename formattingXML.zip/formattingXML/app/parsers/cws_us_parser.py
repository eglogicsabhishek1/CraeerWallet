import xml.sax

class CWSHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.jobs = []
        self.current_data = ""
        self.buffer = ""
        self.current_job = None

    def startElement(self, tag, attrs):
        self.current_data = tag
        self.buffer = ""
        if tag == "job":
            self.current_job = {}

    def endElement(self, tag):
        if self.current_job is not None:
            if self.current_data == "title":
                self.current_job["title"] = self.buffer.strip()
            elif self.current_data == "company":
                self.current_job["company"] = self.buffer.strip()
            elif self.current_data == "location":
                self.current_job["location"] = self.buffer.strip()
            elif self.current_data == "url":
                self.current_job["url"] = self.buffer.strip()
            elif self.current_data == "body":
                self.current_job["description"] = self.buffer.strip()
            elif self.current_data == "job_reference":
                self.current_job["reference"] = self.buffer.strip()
            elif self.current_data == "cpc":
                try:
                    self.current_job["cpc"] = float(self.buffer.strip())
                except:
                    self.current_job["cpc"] = None

            if tag == "job":
                self.jobs.append(self.current_job)
                self.current_job = None

        self.current_data = ""
        self.buffer = ""

    def characters(self, content):
        self.buffer += content
import xml.sax

class CWSHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.jobs = []
        self.current_data = ""
        self.buffer = ""
        self.current_job = None

    def startElement(self, tag, attrs):
        self.current_data = tag
        self.buffer = ""
        if tag == "job":
            self.current_job = {}

    def endElement(self, tag):
        if self.current_job is not None:
            if self.current_data == "title":
                self.current_job["title"] = self.buffer.strip()
            elif self.current_data == "company":
                self.current_job["company"] = self.buffer.strip()
            elif self.current_data == "location":
                self.current_job["location"] = self.buffer.strip()
            elif self.current_data == "url":
                self.current_job["url"] = self.buffer.strip()
            elif self.current_data == "body":
                self.current_job["description"] = self.buffer.strip()
            elif self.current_data == "job_reference":
                self.current_job["reference"] = self.buffer.strip()
            elif self.current_data == "cpc":
                try:
                    self.current_job["cpc"] = float(self.buffer.strip())
                except:
                    self.current_job["cpc"] = None

            if tag == "job":
                self.jobs.append(self.current_job)
                self.current_job = None

        self.current_data = ""
        self.buffer = ""

    def characters(self, content):
        self.buffer += content
