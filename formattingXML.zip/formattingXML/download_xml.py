import requests

url = 'https://www.careerweb.site/jobFeeds/getFeed.php?jobBoard=a3c3e5g7132&jobBoardName=careerwallet'  # Replace with the actual XML file URL
response = requests.get(url)

if response.status_code == 200:
    with open('data.xml', 'wb') as file:
        file.write(response.content)
    print("Download successful!")
else:
    print(f"Failed to download. Status code: {response.status_code}")
